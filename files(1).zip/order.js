/* ==============================================================
   GENETIGZ — ORDER GATING + MODAL PICKERS
   Works on any page that has the existing #productModal markup
   (index.html, collection.html, etc.) without needing to touch
   modal.js/collections.js — it watches the modal from the outside
   and progressively enhances it each time it opens.

   What it does:
   1. Turns the plain "Available Sizes" / "Available Colors" text
      into clickable pills (parsed fresh from whatever modal.js put
      there — no hardcoded product data).
   2. Adds a Quantity +/- stepper (default 1).
   3. Intercepts every click on #modalWhatsapp, sitewide, in the
      capture phase — so it runs before any existing handler and can
      cancel the default navigation:
        - not logged in  -> stash the pending order + redirect to
          login.html?redirect=<this page>
        - logged in but no size/color selected -> inline validation
        - logged in + valid -> POST /api/orders, then open WhatsApp
   4. On page load, if a pending order is waiting (person just came
      back from login), restores it into the modal the next time it
      opens for that same product, and makes a best-effort attempt to
      reopen that product's modal automatically. If that guess fails
      (we don't have modal.js's source, so this is best-effort), a
      small toast still lets them jump back in with one click.

   Requires gz-config.js + auth.js loaded first.
============================================================== */

(function () {
  'use strict';

  var PENDING_KEY = 'gz_pending_order';

  var COLOR_HEX = {
    black: '#1c1206', white: '#f8f3e8', navy: '#1f2a44', olive: '#5b5a35',
    maroon: '#5c1f22', grey: '#8a8a86', gray: '#8a8a86', beige: '#e6d9bd',
    cream: '#f6e8c2', red: '#8c2a2a', blue: '#2a4a8c', green: '#3f5c3f',
    mustard: '#c99a2e', brown: '#4a3524', khaki: '#a99a6b', charcoal: '#37312a',
    'off-white': '#f8f3e8', pink: '#c98a95', orange: '#c1622c', yellow: '#d9b23a',
  };

  /* ----------------------------------------------------------------
     PENDING ORDER (localStorage) — survives the trip to login.html
  ------------------------------------------------------------------- */
  function savePendingOrder(data) {
    try { window.localStorage.setItem(PENDING_KEY, JSON.stringify(data)); } catch (err) {}
  }
  function getPendingOrder() {
    try {
      var raw = window.localStorage.getItem(PENDING_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (err) { return null; }
  }
  function clearPendingOrder() {
    try { window.localStorage.removeItem(PENDING_KEY); } catch (err) {}
  }

  /* ----------------------------------------------------------------
     SMALL HELPERS
  ------------------------------------------------------------------- */
  function parseList(text) {
    return String(text || '')
      .split(/[,/|]/)
      .map(function (s) { return s.trim(); })
      .filter(Boolean);
  }

  function extractPhone(href) {
    var match = String(href || '').match(/wa\.me\/(\d+)/);
    return match ? match[1] : null;
  }

  function buildMessage(productName, productId, size, color, qty) {
    return (
      'Hi Genetigz, I\'d like to order:\n' +
      'Product: ' + productName + ' (' + productId + ')\n' +
      'Size: ' + size + '\n' +
      'Color: ' + color + '\n' +
      'Quantity: ' + qty
    );
  }

  /* ----------------------------------------------------------------
     MODAL ENHANCEMENT
     Runs every time #productModal transitions to "open". Rebuilds the
     size/color pickers fresh from whatever text modal.js just put in
     #modalSizes / #modalColors, and adds a quantity row once.
  ------------------------------------------------------------------- */
  var selection = { size: null, color: null, qty: 1 };

  function currentProductId() {
    var el = document.getElementById('modalCode');
    return el ? el.textContent.trim() : '';
  }
  function currentProductName() {
    var el = document.getElementById('modalProductName');
    return el ? el.textContent.trim() : '';
  }

  function buildPillRow(container, values, groupName, onSelect) {
    container.innerHTML = '';
    var row = document.createElement('div');
    row.className = 'gz-pill-row';

    values.forEach(function (value) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'gz-pill';
      btn.dataset.value = value;
      btn.setAttribute('aria-pressed', 'false');

      if (groupName === 'color') {
        var hex = COLOR_HEX[value.toLowerCase()];
        if (hex) {
          var swatch = document.createElement('span');
          swatch.className = 'gz-swatch';
          swatch.style.background = hex;
          btn.appendChild(swatch);
        }
      }
      var label = document.createElement('span');
      label.textContent = value;
      btn.appendChild(label);

      btn.addEventListener('click', function () {
        row.querySelectorAll('.gz-pill').forEach(function (el) {
          el.classList.remove('is-selected');
          el.setAttribute('aria-pressed', 'false');
        });
        btn.classList.add('is-selected');
        btn.setAttribute('aria-pressed', 'true');
        onSelect(value);
        var specRow = container.closest('.spec-row');
        if (specRow) specRow.classList.remove('has-error');
      });

      row.appendChild(btn);
    });

    container.appendChild(row);
  }

  function ensureQtyRow(specsList) {
    var existing = specsList.querySelector('.gz-qty-row');
    if (existing) return existing.querySelector('.gz-qty-value');

    var row = document.createElement('div');
    row.className = 'spec-row gz-qty-row';

    var dt = document.createElement('dt');
    dt.textContent = 'Quantity';

    var dd = document.createElement('dd');
    var stepper = document.createElement('div');
    stepper.className = 'gz-qty-stepper';

    var minusBtn = document.createElement('button');
    minusBtn.type = 'button';
    minusBtn.className = 'gz-qty-btn';
    minusBtn.setAttribute('aria-label', 'Decrease quantity');
    minusBtn.textContent = '−';

    var valueEl = document.createElement('span');
    valueEl.className = 'gz-qty-value';
    valueEl.textContent = '1';

    var plusBtn = document.createElement('button');
    plusBtn.type = 'button';
    plusBtn.className = 'gz-qty-btn';
    plusBtn.setAttribute('aria-label', 'Increase quantity');
    plusBtn.textContent = '+';

    minusBtn.addEventListener('click', function () {
      selection.qty = Math.max(1, selection.qty - 1);
      valueEl.textContent = String(selection.qty);
    });
    plusBtn.addEventListener('click', function () {
      selection.qty = Math.min(99, selection.qty + 1);
      valueEl.textContent = String(selection.qty);
    });

    stepper.appendChild(minusBtn);
    stepper.appendChild(valueEl);
    stepper.appendChild(plusBtn);
    dd.appendChild(stepper);
    row.appendChild(dt);
    row.appendChild(dd);

    specsList.appendChild(row);
    return valueEl;
  }

  function enhanceModal() {
    var sizesDd = document.getElementById('modalSizes');
    var colorsDd = document.getElementById('modalColors');
    var specsList = document.querySelector('.modal-specs');
    if (!sizesDd || !colorsDd || !specsList) return;

    selection = { size: null, color: null, qty: 1 };

    var sizeValues = parseList(sizesDd.textContent);
    var colorValues = parseList(colorsDd.textContent);

    buildPillRow(sizesDd, sizeValues, 'size', function (value) { selection.size = value; });
    buildPillRow(colorsDd, colorValues, 'color', function (value) { selection.color = value; });

    var qtyValueEl = ensureQtyRow(specsList);

    // Restore a pending selection if we're reopened for the same product.
    var pending = getPendingOrder();
    if (pending && pending.productId === currentProductId()) {
      if (pending.size) {
        var sizeBtn = sizesDd.querySelector('.gz-pill[data-value="' + CSS.escape(pending.size) + '"]');
        if (sizeBtn) sizeBtn.click();
      }
      if (pending.color) {
        var colorBtn = colorsDd.querySelector('.gz-pill[data-value="' + CSS.escape(pending.color) + '"]');
        if (colorBtn) colorBtn.click();
      }
      if (pending.qty) {
        selection.qty = pending.qty;
        if (qtyValueEl) qtyValueEl.textContent = String(pending.qty);
      }

      var whatsappBtn = document.getElementById('modalWhatsapp');
      if (whatsappBtn) {
        whatsappBtn.classList.add('gz-highlight');
        window.setTimeout(function () { whatsappBtn.classList.remove('gz-highlight'); }, 3000);
        showOrderStatus(whatsappBtn, 'Your selection was restored — click Order on WhatsApp to continue.', null);
      }
    }
  }

  function observeModal() {
    var modal = document.getElementById('productModal');
    if (!modal) return;

    var wasOpen = false;
    var observer = new MutationObserver(function () {
      var isOpen = modal.classList.contains('is-open');
      if (isOpen && !wasOpen) {
        window.requestAnimationFrame(enhanceModal);
      }
      wasOpen = isOpen;
    });
    observer.observe(modal, { attributes: true, attributeFilter: ['class', 'aria-hidden'] });
  }

  /* ----------------------------------------------------------------
     VALIDATION + STATUS MESSAGE
  ------------------------------------------------------------------- */
  function showOrderStatus(whatsappBtn, message, type) {
    var status = whatsappBtn.parentElement.querySelector('.gz-order-status');
    if (!status) {
      status = document.createElement('p');
      status.className = 'gz-order-status';
      whatsappBtn.insertAdjacentElement('afterend', status);
    }
    status.textContent = message || '';
    status.className = 'gz-order-status' + (type ? ' is-' + type : '');
  }

  function markFieldError(id, message) {
    var dd = document.getElementById(id);
    if (!dd) return;
    var specRow = dd.closest('.spec-row');
    if (!specRow) return;
    specRow.classList.add('has-error');
    var errorEl = specRow.querySelector('.gz-field-error');
    if (!errorEl) {
      errorEl = document.createElement('span');
      errorEl.className = 'gz-field-error';
      dd.appendChild(errorEl);
    }
    errorEl.textContent = message;
  }

  function validateSelection() {
    var valid = true;
    if (!selection.size) { markFieldError('modalSizes', 'Please select a size.'); valid = false; }
    if (!selection.color) { markFieldError('modalColors', 'Please select a color.'); valid = false; }
    return valid;
  }

  /* ----------------------------------------------------------------
     ORDER SUBMIT (auth check -> save -> WhatsApp)
  ------------------------------------------------------------------- */
  function handleWhatsAppClick(e, whatsappBtn) {
    e.preventDefault();
    e.stopImmediatePropagation();

    var productId = currentProductId();
    var productName = currentProductName();

    if (!validateSelection()) return;

    var originalHref = whatsappBtn.getAttribute('href') || '';
    var phone = extractPhone(originalHref) || '918145532620';
    var message = buildMessage(productName, productId, selection.size, selection.color, selection.qty);
    var waUrl = 'https://wa.me/' + phone + '?text=' + encodeURIComponent(message);

    if (!window.GZAuth || !window.GZAuth.isLoggedIn()) {
      savePendingOrder({
        productId: productId,
        productName: productName,
        size: selection.size,
        color: selection.color,
        qty: selection.qty,
        returnUrl: window.location.href,
      });
      window.location.href = 'login.html?redirect=' + encodeURIComponent(window.location.href);
      return;
    }

    whatsappBtn.classList.add('is-loading');
    showOrderStatus(whatsappBtn, 'Saving your order…', null);

    window.GZAuth.apiFetch('/orders', {
      method: 'POST',
      body: JSON.stringify({
        productId: productId,
        productName: productName,
        size: selection.size,
        color: selection.color,
        quantity: selection.qty,
      }),
    })
      .then(function (data) {
        clearPendingOrder();
        showOrderStatus(whatsappBtn, 'Order saved — opening WhatsApp…', 'success');
        var opened = window.open(waUrl, '_blank', 'noopener');

        // Best-effort status update; a failure here doesn't block checkout.
        if (data && data.order && data.order._id) {
          window.GZAuth.apiFetch('/orders/' + data.order._id + '/status', {
            method: 'PATCH',
            body: JSON.stringify({ status: opened ? 'opened' : 'pending' }),
          }).catch(function () {});
        }
      })
      .catch(function (err) {
        showOrderStatus(
          whatsappBtn,
          err.status === 401
            ? 'Your session expired — please sign in again.'
            : 'Could not save your order. Opening WhatsApp anyway — please keep this chat as proof.',
          'error'
        );
        if (err.status === 401) {
          window.GZAuth.logout();
          savePendingOrder({
            productId: productId, productName: productName,
            size: selection.size, color: selection.color, qty: selection.qty,
            returnUrl: window.location.href,
          });
          window.location.href = 'login.html?redirect=' + encodeURIComponent(window.location.href);
          return;
        }
        window.open(waUrl, '_blank', 'noopener');
      })
      .finally(function () {
        whatsappBtn.classList.remove('is-loading');
      });
  }

  function initGlobalClickGate() {
    document.addEventListener(
      'click',
      function (e) {
        var target = e.target.closest('#modalWhatsapp, .btn-whatsapp');
        if (!target) return;
        handleWhatsAppClick(e, target);
      },
      true // capture phase — runs before modal.js's own handlers, if any
    );
  }

  /* ----------------------------------------------------------------
     RETURNING FROM LOGIN WITH A PENDING ORDER
     Best-effort auto-reopen: we don't have collections.js/modal.js's
     source, so we look for a product card carrying the same code/id
     as text or a data attribute and simulate a click on it. If that
     doesn't find anything, we still show a toast so the person can
     jump back in manually — and the moment they open that product's
     modal themselves, enhanceModal() restores their selection anyway.
  ------------------------------------------------------------------- */
  function attemptAutoReopen(pending) {
    var candidates = document.querySelectorAll(
      '[data-code="' + CSS.escape(pending.productId) + '"], ' +
      '[data-id="' + CSS.escape(pending.productId) + '"], ' +
      '.product-card'
    );
    for (var i = 0; i < candidates.length; i++) {
      var el = candidates[i];
      var matchesById = el.dataset.code === pending.productId || el.dataset.id === pending.productId;
      var matchesByText = el.textContent.indexOf(pending.productName) !== -1;
      if (matchesById || matchesByText) {
        el.click();
        return true;
      }
    }
    return false;
  }

  function showPendingToast(pending) {
    var toast = document.createElement('div');
    toast.className = 'gz-pending-toast';
    toast.innerHTML =
      '<span>Continue your order — ' + pending.productName + '</span>';

    var resumeBtn = document.createElement('button');
    resumeBtn.textContent = 'Resume';
    resumeBtn.addEventListener('click', function () {
      attemptAutoReopen(pending);
      toast.classList.remove('is-visible');
    });

    var dismissBtn = document.createElement('button');
    dismissBtn.className = 'gz-toast-dismiss';
    dismissBtn.textContent = 'Dismiss';
    dismissBtn.addEventListener('click', function () {
      toast.classList.remove('is-visible');
    });

    toast.appendChild(resumeBtn);
    toast.appendChild(dismissBtn);
    document.body.appendChild(toast);

    window.requestAnimationFrame(function () {
      toast.classList.add('is-visible');
    });
  }

  function handleReturnFromLogin() {
    var pending = getPendingOrder();
    if (!pending) return;

    // Give collections.js/modal.js time to render product cards first.
    window.setTimeout(function () {
      var reopened = attemptAutoReopen(pending);
      if (!reopened) showPendingToast(pending);
    }, 700);

    document.addEventListener('gz:productsRendered', function () {
      attemptAutoReopen(pending);
    });
  }

  function init() {
    observeModal();
    initGlobalClickGate();
    handleReturnFromLogin();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
